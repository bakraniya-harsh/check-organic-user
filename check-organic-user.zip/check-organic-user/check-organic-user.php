<?php
/**
 * Plugin Name: Check organic user
 * Description: Display different menus based on organic traffic detection
 * Version: 1.0
 * Author: Spaceo Tech
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

function check_organic_user() {

    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    // echo '<pre>';
    // print_r($user_agent);
    // echo '</pre>';

    $browser = "";
    if(strpos($user_agent, 'Edge') !== FALSE || strpos($user_agent, 'Edg') !== FALSE) {
        $browser = "Microsoft Edge";
    }elseif (strpos($user_agent, 'Opera Mini') !== FALSE) {
        $browser = "Opera Mini";
    }elseif (strpos($user_agent, 'Opera') !== FALSE || strpos($user_agent, 'OPR') !== FALSE) {
        $browser = "Opera";
    }elseif (strpos($user_agent, 'Chrome') !== FALSE) {
        $browser = "Google Chrome";
    }elseif (strpos($user_agent, 'Safari') !== FALSE) {
        $browser = "Safari";
    }elseif (strpos($user_agent, 'Firefox') !== FALSE) {
        $browser = "Mozilla Firefox";
    }elseif (strpos($user_agent, 'Trident') !== FALSE || strpos($user_agent, 'MSIE') !== FALSE) {
        $browser = "Internet Explorer";
    }
        
    if ($browser) {
        $expiration_time = time() + (30 * DAY_IN_SECONDS);
        setcookie('organic_user', $browser, $expiration_time, '/');
    }
}
add_action('init', 'check_organic_user');


function change_menu($args) {
    if(isset($_COOKIE['organic_user']) && !empty($_COOKIE['organic_user'])) {
        if(isset($args['menu']) && $args['menu'] === 'Main menu') {
            $args['menu'] = 'Organic Menu';
        }
        if(isset($args['theme_location']) && $args['theme_location'] === 'primary') {
            $args['menu'] = 'Organic Menu';
        }
    }
    return $args;
}
add_filter('wp_nav_menu_args', 'change_menu');