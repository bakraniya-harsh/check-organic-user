<?php
/**
 * Plugin Name: Organic Menu Switcher
 * Description: Dynamically switches the primary menu to an 'Organic Menu'
 *              if the user arrives from an organic search engine, persisting
 *              this choice for the session.
 * Version:     1.0.1
 * Author:      Spaceo
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Organic_Menu_Switcher {

    private $organic_menu_name = 'Organic Menu';
    private $target_theme_location = 'main-menu';
    private $cookie_name = 'oms_is_organic';

    public function __construct() {
        add_action( 'init', array( $this, 'detect_organic_traffic' ) );
        add_filter( 'wp_nav_menu_args', array( $this, 'modify_menu_based_on_traffic' ) );
    }

    public function detect_organic_traffic() {
        
        if ( isset( $_COOKIE[ $this->cookie_name ] ) ) {
            return;
        }

        $referrer = isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( $_SERVER['HTTP_REFERER'] ) : '';
        echo "Current script: " . $_SERVER['PHP_SELF'] . "<br>";
        echo "Server Name: " . $_SERVER['SERVER_NAME'] . "<br>";
        echo "Request Method: " . $_SERVER['REQUEST_METHOD'] . "<br>";
        echo "Client IP Address: " . $_SERVER['REMOTE_ADDR'] . "<br>";
        echo "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "<br>";
        echo '<pre>';
        print_r($referrer);
        echo '</pre>';
        $is_organic = false;

        $organic_sources = array(
            'google.',
            'bing.',
            'yahoo.',
            'duckduckgo.',
            'ecosia.',
            'ask.',
            'baidu.',
            'yandex.',
        );

        if ( ! empty( $referrer ) ) {
            foreach ( $organic_sources as $source ) {
                if ( strpos( $referrer, $source ) !== false ) {
                    $is_organic = true;
                    break;
                }
            }
        }

        setcookie( $this->cookie_name, $is_organic ? '1' : '0', time() + 2 * HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
        $_COOKIE[ $this->cookie_name ] = $is_organic ? '1' : '0';
    }

    public function modify_menu_based_on_traffic( $args ) {
        if ( isset( $args['theme_location'] ) && $args['theme_location'] === $this->target_theme_location ) {
            if ( isset( $_COOKIE[ $this->cookie_name ] ) && $_COOKIE[ $this->cookie_name ] === '1' ) {
                $args['menu'] = $this->organic_menu_name;
            }
        }
        return $args;
    }
}

new Organic_Menu_Switcher();